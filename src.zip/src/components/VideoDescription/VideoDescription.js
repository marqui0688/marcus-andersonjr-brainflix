import "./VideoDescription.scss";

function VideoDescription(props) {
  console.log(props);
  return (
    <section className="description-container">
      <p
        className="description-container__text"
        src={props.mainVideoDescription.description}
      ></p>
    </section>
  );
}

export default VideoDescription;
