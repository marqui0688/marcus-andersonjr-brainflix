import viewsIcon from "../../assets/Images/Icons/views.svg";
import viewsLikes from "../../assets/Images/Icons/likes.svg";

import "./VideoViews.scss";

function VideoViews() {
  return (
    <div className="views-container">
      <div className="video-views">
        <p className="video-views__author">By Red Crow</p>
        <img className="video-views__icon" src={viewsIcon} alt="views icon" />
        <p className="video-views__counter">1,001,023</p>
      </div>

      <div className="video-likes">
        <p className="video-likes__date">7/11/2021</p>
        <img className="video-likes__icon" src={viewsLikes} alt="views like" />
        <p className="video-views__counter">110,985</p>
      </div>
    </div>
  );
}

export default VideoViews;
